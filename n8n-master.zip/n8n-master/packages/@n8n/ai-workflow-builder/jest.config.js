/** @type {import('jest').Config} */
module.exports = {
	...require('../../../jest.config'),
	testTimeout: 10_000,
};
